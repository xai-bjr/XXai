# GearOrbit — Cars × Space × Agents × Code

A tiny, no-dependency starter website that blends your hobbies:

- **Garage** — filter a mini car dataset
- **Orbit** — mock launch board
- **Ops** — tradecraft mini tools (Caesar cipher + OSINT tips)
- **Code Lab** — run JavaScript in the browser

## Run

Just open `index.html` in a browser. No build step.

## Customize

- Edit `data/cars.json` and `data/launches.json` to add real data.
- Style via `css/styles.css`.
- Add pages by extending the `routes` in `js/router.js` and a renderer in `js/app.js`.

## License

MIT — do whatever, no warranty.
