
import { resolveRoute, setActiveLink } from './router.js';

const $app = document.getElementById('app');
const $year = document.getElementById('year');
$year.textContent = new Date().getFullYear();

// theme
const themeBtn = document.getElementById('themeToggle');
const setTheme = (t)=>{ document.documentElement.classList.toggle('light', t==='light'); localStorage.setItem('theme',t) };
const initTheme = ()=>{ const t = localStorage.getItem('theme') || 'dark'; setTheme(t); themeBtn.textContent = t==='light'?'🌙':'☀️'; };
initTheme();
themeBtn.addEventListener('click', ()=>{
  const now = document.documentElement.classList.contains('light') ? 'dark':'light';
  setTheme(now);
  themeBtn.textContent = now==='light'?'🌙':'☀️';
});

window.addEventListener('hashchange', render);
render();

async function render(){
  setActiveLink();
  const route = resolveRoute();
  if(route === '/') return renderHome();
  if(route === '/garage') return renderGarage();
  if(route === '/orbit') return renderOrbit();
  if(route === '/ops') return renderOps();
  if(route === '/codelab') return renderCodeLab();
}

function section(title, subtitle, inner){
  return \`
    <section class="card">
      <h2 style="margin:0 0 6px">\${title}</h2>
      \${subtitle ? '<div class="badge">'+subtitle+'</div>' : ''}
      <div style="margin-top:12px">\${inner||''}</div>
    </section>
  \`;
}

function renderHome(){
  $app.innerHTML = \`
  <div class="hero card">
    <div>
      <h2 class="big">Cars × Space × Agents × Code</h2>
      <p class="muted">Welcome to <strong>GearOrbit</strong> — a sandbox where petrolheads, stargazers, tradecraft nerds, and coders explore together.</p>
      <div class="cta">
        <a class="btn" href="#/garage">Enter Garage</a>
        <a class="btn" href="#/codelab">Open Code Lab</a>
      </div>
    </div>
    <div class="card">
      <p><strong>Quick Tips</strong></p>
      <ul>
        <li>Use the <span class="kbd">G</span> key to jump to Garage.</li>
        <li>Try the Caesar cipher in Ops.</li>
        <li>Edit & run JS in Code Lab.</li>
      </ul>
    </div>
  </div>
  \`;
  window.addEventListener('keydown', (e)=>{
    if(e.key.toLowerCase()==='g') location.hash = '#/garage';
  }, {once:true});
}

async function renderGarage(){
  const cars = await (await fetch('data/cars.json')).json();
  $app.innerHTML = \`
    \${section('Garage', 'Filter and explore a tiny demo dataset', \`
      <div class="controls">
        <input id="q" class="input" placeholder="Search make/model..." />
        <select id="fuel">
          <option value="">Fuel (any)</option>
          <option>Petrol</option>
          <option>Hybrid</option>
          <option>Electric</option>
        </select>
        <select id="year">
          <option value="">Year (any)</option>
          <option value=">=2018">2018+</option>
          <option value=">=2015">2015+</option>
          <option value="<2015">&lt; 2015</option>
        </select>
      </div>
      <div id="grid" class="grid"></div>
    \`)}
  \`;
  const $q = document.getElementById('q');
  const $fuel = document.getElementById('fuel');
  const $year = document.getElementById('year');
  const $grid = document.getElementById('grid');

  function filter(){
    const t = ($q.value||'').toLowerCase();
    const fuel = $fuel.value;
    const y = $year.value;
    const filtered = cars.filter(c=>{
      const txt = (c.make+' '+c.model).toLowerCase();
      const okTxt = txt.includes(t);
      const okFuel = !fuel || c.fuel===fuel;
      const okYear = !y || (y.startsWith('>=') ? c.year >= Number(y.slice(2)) : c.year < Number(y.slice(1)));
      return okTxt && okFuel && okYear;
    });
    renderCards(filtered);
  }
  function renderCards(list){
    $grid.innerHTML = list.map(c=>\`
      <div class="card">
        <h3>\${c.make} \${c.model}</h3>
        <div class="badge">\${c.year} • \${c.fuel}</div>
        <p class="muted">Power: \${c.hp} hp</p>
        <p>\${c.tags.map(t=>'<span class="badge" style="margin-right:6px">'+t+'</span>').join('')}</p>
      </div>
    \`).join('');
  }
  [$q,$fuel,$year].forEach(el=>el.addEventListener('input', filter));
  renderCards(cars);
}

async function renderOrbit(){
  const launches = await (await fetch('data/launches.json')).json();
  $app.innerHTML = \`
    \${section('Orbit', 'Mock upcoming launch board', \`
      <table>
        <thead><tr><th>Mission</th><th>Vehicle</th><th>Window</th><th>Site</th><th>Status</th></tr></thead>
        <tbody id="rows"></tbody>
      </table>
    \`)}
  \`;
  const $rows = document.getElementById('rows');
  $rows.innerHTML = launches.map(l=>\`
    <tr>
      <td>\${l.mission}</td>
      <td>\${l.vehicle}</td>
      <td>\${l.window}</td>
      <td>\${l.site}</td>
      <td><span class="badge">\${l.status}</span></td>
    </tr>\`).join('');
}

function caesarShift(s, n){
  const a='abcdefghijklmnopqrstuvwxyz'; const A=a.toUpperCase();
  return [...s].map(ch=>{
    const i=a.indexOf(ch); if(i>=0) return a[(i+n+26)%26];
    const j=A.indexOf(ch); if(j>=0) return A[(j+n+26)%26];
    return ch;
  }).join('');
}

function renderOps(){
  $app.innerHTML = \`
    \${section('Ops', 'Tradecraft mini‑tools', \`
      <div class="controls">
        <input id="plain" class="input" placeholder="Plaintext" />
        <input id="shift" class="input" type="number" value="3" />
        <button id="enc" class="btn">Encrypt (Caesar)</button>
        <button id="dec" class="btn">Decrypt</button>
      </div>
      <pre id="out" aria-live="polite"></pre>
      <details style="margin-top:10px"><summary>OSINT Starter Tips</summary>
        <ul>
          <li>Reverse image search variants: crop faces, blur background, try different rotations.</li>
          <li>Time-box searches and keep a research log.</li>
          <li>Correlate 2+ independent signals before concluding.</li>
        </ul>
      </details>
    \`)}
  \`;
  const $p = document.getElementById('plain');
  const $s = document.getElementById('shift');
  const $out = document.getElementById('out');
  document.getElementById('enc').onclick = ()=> $out.textContent = caesarShift($p.value, Number($s.value||0));
  document.getElementById('dec').onclick = ()=> $out.textContent = caesarShift($p.value, -Number($s.value||0));
}

function renderCodeLab(){
  $app.innerHTML = \`
    \${section('Code Lab', 'Write JS and run it safely (no network)', \`
      <textarea id="code" class="input" style="min-height:150px" spellcheck="false">// Try: const sum = (a,b)=>a+b; sum(2,5)</textarea>
      <div class="controls">
        <button id="run" class="btn">Run ▶</button>
        <button id="clear" class="btn">Clear</button>
      </div>
      <pre id="result"></pre>
    \`)}
  \`;
  const $code = document.getElementById('code');
  const $result = document.getElementById('result');
  document.getElementById('run').onclick = ()=>{
    try{
      // eslint-disable-next-line no-new-func
      const out = Function('"use strict";\n' + $code.value)();
      $result.textContent = String(out);
    }catch(err){
      $result.textContent = 'Error: ' + err.message;
    }
  };
  document.getElementById('clear').onclick = ()=>{ $result.textContent=''; $code.value=''; };
}
