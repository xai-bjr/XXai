
// super-tiny hash router
const routes = {
  "/": "home",
  "/garage": "garage",
  "/orbit": "orbit",
  "/ops": "ops",
  "/codelab": "codelab",
};

export function resolveRoute() {
  const hash = location.hash.replace('#','') || '/';
  return routes[hash] ? routes[hash] : '/';
}

export function setActiveLink() {
  document.querySelectorAll('[data-route]').forEach(a=>{
    const r = a.getAttribute('href').replace('#','');
    a.classList.toggle('active', r === (location.hash || '#/'));
  });
}
